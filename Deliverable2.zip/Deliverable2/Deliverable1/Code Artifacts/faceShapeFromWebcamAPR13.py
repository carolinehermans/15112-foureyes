from Tkinter import *
import Tkinter as tk
import cv2
from PIL import Image, ImageTk
import os

#####FACE SHAPE ALGORITHM HERE#######
def areSimilarDimensions(lenA,lenB):
    ratio = 1.0*lenA/lenB
    #saying that the ratio almost equals 1, with some room for variation
    allowedRatioDifference=0.3
    return abs(ratio-1.0)<=allowedRatioDifference

def areSimilarRatios(ratioA,ratioB):
    allowedRatioDifference=0.15
    return abs(ratioA-ratioB)<=allowedRatioDifference

def isHeartFace(faceDimensions):
    forehead,jaw,faceLength,faceWidth=faceDimensions
    #A face is heart shaped if the forehead is significantly wider than the jaw.
    foreheadJawRatio=1.0*forehead/jaw
    differentSizeRatio=1.2
    #checking if the forehead is significantly the widest part of the face
    return foreheadJawRatio>differentSizeRatio

def isOvalFace(faceDimensions):
    forehead,jaw,faceLength,faceWidth=faceDimensions
    #A face is oval shaped if the face is approx 1.5 times as long as 
    #it is wide or more, but it was too sensitive so 1.55 gives more accurate
    #results
    lengthWidthRatio=1.0*faceLength/faceWidth
    idealOvalRatio=1.55
    return lengthWidthRatio>=idealOvalRatio

def isSquareFace(faceDimensions):
    #a face is square if the forehead and jaw are approximately the same width
    forehead,jaw,faceLength,faceWidth=faceDimensions
    print forehead
    print jaw
    foreheadJawRatio=1.0*forehead/jaw
    print foreheadJawRatio
    idealSquareForeheadJawRatio=1.0
    return areSimilarRatios(foreheadJawRatio,idealSquareForeheadJawRatio)

def getFaceShape(faceDimensions):
    #heart is the next distinctive, if the forehead is the widest, that
    #person's face is definitely a heart. therefore, it gets checked first.
    if isHeartFace(faceDimensions)==True:
        return "heart"
    #oval is the next most distinctive, so it gets checked second. If the length 
    #is about 1.5 times the width, it's an oval.
    if isOvalFace(faceDimensions)==True:
        return "oval"
    #then comes square, with angular features and similar widths everywhere
    elif isSquareFace(faceDimensions)==True:
        return "square"
    #last remaining face shape
    else: return "round"

def getFaceDimensions(dots):
    #the information about distances is stored in the dots made earlier
    (ax,ay)=dots[0].cx,dots[0].cy
    (bx,by)=dots[1].cx,dots[1].cy
    (cx,cy)=dots[2].cx,dots[2].cy
    (dx,dy)=dots[3].cx,dots[3].cy
    (ex,ey)=dots[4].cx,dots[4].cy
    (fx,fy)=dots[5].cx,dots[5].cy
    #distance formula between particular dots
    foreheadWidth=((fx-bx)**2+(fy-by)**2)**0.5
    jawWidth=((ex-cx)**2+(ey-cy)**2)**0.5
    faceLength=((ax-dx)**2+(ay-dy)**2)**0.5
    faceWidth=(foreheadWidth+jawWidth)/2.0
    return (foreheadWidth,jawWidth,faceLength,faceWidth)

#####TKINTER AND OPENCV STUFF######
class Struct: pass
class Dot(object):
    def __init__(self,x,y,n):
        self.cx=x
        self.cy=y
        self.r=6
        self.n=n
    def draw(self,canvas):
        x,y=self.cx,self.cy
        r=self.r
        canvas.create_oval(x-r,y-r,x+r,y+r,fill="white")
        #canvas.create_text(x,y,text=str(self.n))
    def clickInside(self,x,y):
        r=self.r*2 #gives user extra distance to mess up their click a bit
        if (x>self.cx-r and x<self.cx+r
         and y>self.cy-r and y<self.cy+r):
            return True
        return False

#from course notes
def rgbString(red, green, blue):
    return "#%02x%02x%02x" % (red, green, blue)

def drawStartScreen():
    #sets up colors for the program
    data.backgroundColor=rgbString(66,51,98)
    data.accentColor=rgbString(195,186,235)
    data.highlightColor=rgbString(255,255,255)
    #sets up size of the button
    data.startButton=(data.width/3, 2.5*data.height/4, 2*data.width/3, 
        3*data.height/4)
    x0b,y0b,x1b,y1b=data.startButton
    #draws the background
    #canvas.create_rectangle(0,0,data.width*2,data.height*2,
       # fill=data.backgroundColor,width=0)
    #draws the button 
    canvas.create_rectangle(x0b,y0b,x1b,y1b,fill=data.highlightColor,width=0)
    text="Take a Photo"
    font="Verdana 45 bold"
    #draws the button text
    canvas.create_text((x0b+x1b)/2,(y0b+y1b)/2,anchor="c",
        fill=data.backgroundColor, text=text, font=font)
    mainText="FourEyes"
    font="Eurostile 160 bold"
    #draws the title
    canvas.create_text(data.width/2,data.height/4,anchor="c",
        fill=data.highlightColor,text=mainText,font=font)
    filler1="Learn which glasses frames will look"
    filler2="the best with your face shape."
    font="Verdana 35"
    #draws the descriptions
    canvas.create_text(data.width/2,1.7*data.height/4,anchor="c",
        fill=data.accentColor,text=filler1,font=font)
    canvas.create_text(data.width/2,1.9*data.height/4,anchor="c",
        fill=data.accentColor,text=filler2,font=font)

def drawBackground():
    #draws the purple area around the image
    data.backgroundColor=rgbString(66,51,98)
    rectW,rectH=1200,800
    data.offset=50
    offset=data.offset
    canvas.create_rectangle(0,0,rectW*2,rectH*2,
        fill=data.backgroundColor,width=0)

def drawDoneWithDotsButton():
    #draws the "done" button for users to press
    data.doneWithDotsButton=230,690,470,760
    x0,y0,x1,y1=data.doneWithDotsButton
    canvas.create_rectangle(x0,y0,x1,y1,fill=data.highlightColor,width=0)
    text="DONE"
    font="Verdana 50"
    canvas.create_text((x0+x1)/2,(y0+y1)/2,anchor="c",text=text,
        font=font,fill=data.backgroundColor)

def drawTakeAPhotoScreen():
    text="Take a Photo"
    font="Verdana 80 bold"
    canvas.create_text(data.width/2,data.height/8,text=text,font=font,
        fill="white")
    xoffset=30
    yoffset=180
    x2=670
    y2=670
    canvas.create_rectangle(xoffset,yoffset,x2,y2,fill=data.accentColor,width=0)
    drawInstructionText()
    drawPhotoIcon()

def drawPhotoIcon():
    img=ImageTk.PhotoImage(file="camera.gif")
    data.imageLabel._image_cache=img
    x=350
    canvas.create_image(x,data.height-data.height/12,
        anchor="c",image=img)


def drawInstructionText():
    rule1="1. Put your hair back"
    rule2="2. Put your entire"
    rule2b="face in the frame"
    rule3="3. Make sure there is"
    rule3b="light on your face"
    color=data.accentColor
    smallspc=50
    spc=100
    font="Verdana 40"
    x0,y0=data.width-data.width/4, 250
    canvas.create_text(x0,y0,anchor="c",text=rule1,fill=color,font=font)
    canvas.create_text(x0,y0+spc,anchor="c",text=rule2,fill=color,font=font)
    canvas.create_text(x0,y0+spc+smallspc,anchor="c",text=rule2b,fill=color,
        font=font)
    canvas.create_text(x0,y0+spc+smallspc+spc,anchor="c",text=rule3,fill=color,
        font=font)
    canvas.create_text(x0,y0+spc+smallspc+spc+smallspc,anchor="c",text=rule3b,
        fill=color,font=font)

def drawAll(canvas):
    drawBackground()
    if data.start==False:
        drawStartScreen()
    else:
        if data.pause==False:
            drawTakeAPhotoScreen()
            drawFrame(canvas,data.currImg)
        else:
            drawDotScreen()
            drawFrame(canvas,data.pauseImg)
            for dot in data.dots:
                dot.draw(canvas)

def clickDoneWithDots(x,y):
    x0,y0,x1,y1=data.doneWithDotsButton
    if x>x0 and x<x1 and y>y0 and y<y1: return True

def sortDots():
    numDots=6
    newDots=[]
    for i in xrange(numDots):
        for dot in data.dots:
            if dot.n==i:
                newDots.append(dot)
    return newDots

def onMouseUp(event):
    if data.clicked==True:
        n=data.clickedDot.n
        data.dots.remove(data.clickedDot)
        data.dots.append(Dot(event.x,event.y,n))
        data.dots=sortDots()
        drawAll(canvas)

def clickInStartButton(x,y):
    x0,y0,x1,y1=data.startButton
    return x>x0 and x<x1 and y>y0 and y<y1

def clickInPhotoButton(x,y):
    x0=350-100
    x1=350+100
    y0=data.height-data.height/12-100
    y1=data.height-data.height/12+100
    if x>x0 and x<x1 and y>y0 and y<y1: return True
    return False

def onMouseDown(event):
    if data.start==False:
        if clickInStartButton(event.x,event.y):
            data.start=True
    if data.pause==False and data.start==True:
        if clickInPhotoButton(event.x,event.y):
            data.pause=True
            ret,frame=data.cap.read()
            frame=cv2.flip(frame,1)
            #find the face bounding box on the paused frame
            data.facerect=detectFace(frame)
    if data.pause==True:
        for dot in data.dots:
            if dot.clickInside(event.x,event.y):
                data.clicked=True
                data.clickedDot=dot
                return
        data.clicked=False
        if clickDoneWithDots(event.x,event.y):
            faceDimensions=getFaceDimensions(data.dots)
            data.faceShape=getFaceShape(faceDimensions)
            drawFaceShapeScreen()

def keyPressed(event):
    pass
    if event.keysym=="space":
        #if they hit the space bar, pause the feed
        data.pause=True
        
def drawFrame(canvas,img):
    #draws the webcam feed
    xoffset=50
    yoffset=200
    canvas.create_image(xoffset,yoffset,anchor=NW,image=img)

def drawDots():
    drawBackground()
    drawFrame(canvas,data.pauseImg)#########
    for dot in data.dots:
        dot.draw(canvas)

def readFile(filename, mode="rt"):
    # rt = "read text"
    with open(filename, mode) as fin:
        return fin.read()

def drawFaceShapeScreen():
    drawBackground()
    text1="Your face shape is"
    text2=data.faceShape[0].upper()+data.faceShape[1:]
    filename=str(data.faceShape)+".txt"
    #GET THIS TO LOOK GOOD USING THING FROM MIDTERM
    writeup=readFile("shapes/"+filename)
    font1="Verdana 60"
    font2="Verdana 170 bold"
    y0=90
    spacing=100
    canvas.create_text(data.width/2,y0,anchor="c",text=text1,font=font1,
        fill=data.highlightColor)
    canvas.create_text(data.width/2,y0+spacing,anchor="c",text=text2,font=font2,
        fill=data.highlightColor)
    drawFaceShapeWriteup(writeup)



def drawFaceShapeWriteup(writeup):
    #puts each line of the writup on a different line
    #figure this out, it's buggy
    wordsPerLine=6
    spacing=60
    y0=350
    font="Verdana 45"
    allText=[]
    writeup=writeup.split(" ")
    numLines=0
    for i in xrange(0,len(writeup)-wordsPerLine,wordsPerLine):
        line=writeup[i:i+wordsPerLine]
        line=(" ").join(line)
        allText.append(line)
        numLines+=1
    lastLine=writeup[len(writeup)-wordsPerLine/2+1:]
    lastLine=(" ").join(lastLine)
    allText.append(lastLine)

    for i in xrange(len(allText)):
        canvas.create_text(data.width/2,y0+spacing*i,text=allText[i],
            fill=data.accentColor,font=font)

    

def drawDotScreen():
    drawBackground()
    drawDoneWithDotsButton()
    text="Place the Dots Accurately"
    font="Verdana 80 bold"
    color=data.highlightColor
    canvas.create_text(data.width/2,data.height/8,text=text,font=font,
        fill=color)
    xoffset=30
    yoffset=180
    x2=670
    y2=670
    canvas.create_rectangle(xoffset,yoffset,x2,y2,fill=data.accentColor,width=0)
    drawDotInstructions()

def drawInstructionImage():
    img=ImageTk.PhotoImage(file="tpFace.gif")
    data.imageLabel._image_cache=img
    x=940
    canvas.create_image(x,data.height-data.height/4,
        anchor="c",image=img)

def drawDotInstructions():
    text2="One dot goes at your hairline"
    text3="Two dots line up with your eyebrows"
    text4="Two dots line up with your mouth"
    text5="One dot goes at your chin"
    color=data.accentColor
    font="Verdana 25"
    x=data.offset+880
    y0=200
    spacing=60
    canvas.create_text(x,y0,anchor="c",text=text2,font=font,fill=color)
    canvas.create_text(x,y0+spacing,anchor="c",text=text3,font=font,fill=color)
    canvas.create_text(x,y0+2*spacing,anchor="c",text=text4,font=font,
        fill=color)
    canvas.create_text(x,y0+3*spacing,anchor="c",text=text5,font=font,
        fill=color)
    drawInstructionImage()

def makeDots():
    ####readjust for face shape, makes dots at expected coordinates#####
    dotList=[]
    x,y,w,h=data.facerect
    babyspc=w/11
    smallspc=w/8
    medspc=w/5
    bigspc=w/4
    offset=data.offset
    yoffset=200
    dot1=Dot(x=x+w/2+offset,y=y-smallspc+yoffset,n=0) 
    dot2=Dot(x=x+w-smallspc+offset,y=y+bigspc+yoffset,n=1)
    dot3=Dot(x=x+w-smallspc+offset,y=y+h/2+bigspc+yoffset,n=2)
    dot4=Dot(x=x+w/2+offset,y=y+h+yoffset,n=3)
    dot5=Dot(x=x+medspc+offset,y=y+h/2+bigspc+yoffset,n=4)
    dot6=Dot(x=x+smallspc+offset,y=y+bigspc+yoffset,n=5)
    return [dot1,dot2,dot3,dot4,dot5,dot6]

def updateAll(canvas):
    #continually updates the function
    img = updateImage()
    if data.pause==True:
        data.pauseImg=img
        drawFrame(canvas,data.pauseImg)
        if data.dots==None: 
            data.facerect=detectFace(data.cv2img)
            data.dots=makeDots()
        drawAll(canvas)
    else:
        data.currImg=img
        drawAll(canvas)
        canvas.after(15,func=lambda:updateAll(canvas))
        
def detectFace(cvFrame):
    #classifies faces, so it knows what to look for
    face_cascade =(
        cv2.CascadeClassifier('haarcascades/haarcascade_frontalface_alt.xml'))
    gray=cv2.cvtColor(cvFrame,cv2.COLOR_BGR2GRAY)
    faces=face_cascade.detectMultiScale(gray, 1.3, 5)
    biggestFaceArea=0
    for face in faces:
        x,y,w,h=face
        #returns the biggest, most significant face it sees
        if (x+w)*(y+h)>biggestFaceArea:
            biggestFaceArea=(x+w)*(y+h)
            biggestFace=x,y,w,h
    #returns four coordinates so that it can draw the face box
    if biggestFaceArea!=0: return biggestFace
    else: return (220, 100, 260, 280)

def updateImage():
    #gets new frame from webcam feed every time it's called
    ret,frame=data.cap.read()
    frame=cv2.flip(frame,1)
    if data.pause==True: data.cv2img=frame
    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    img=Image.fromarray(cv2image)
    h=450
    desiredW=600
    img=img.crop((0,0,desiredW,h))
    #converts to tkinter image
    tkImg=ImageTk.PhotoImage(image=img)
    data.imageLabel._image_cache=tkImg
    return tkImg

def run():
    root=tk.Tk()
    global canvas,data
    imgwidth,imgheight=800,450
    cap = cv2.VideoCapture(0)
    cap.set(3, imgwidth)
    cap.set(4, imgheight)
    w,h=1200,800
    canvas=Canvas(root,width=w,height=h)
    data=Struct()
    data.start=False
    data.dots=None
    data.cap=cap
    data.pause=False
    data.width,data.height=w,h
    data.clicked=False
    data.doneWithDots=False
    canvas.bind("<Button-1>",onMouseDown)
    canvas.bind("<ButtonRelease-1>",onMouseUp)
    root.bind("<Key>",keyPressed)
    canvas.pack()
    canvas.after(0,func=lambda:updateAll(canvas))
    data.imageLabel=tk.Label(root)
    data.imageLabel.pack()
    drawBackground()
    root.mainloop()

run()