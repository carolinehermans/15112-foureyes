import numpy as np
import cv2

cascadePath='haarcascades/haarcascade_frontalface_alt.xml'
face_cascade=cv2.CascadeClassifier(cascadePath)
cap=cv2.VideoCapture(0)

def draw_rects(img, rects, color):
    for x, y, w, h in rects:
        cv2.rectangle(img, (x,y), (x+w,y+h), color, 2)


dy,dx=0,0
r=100
while (True):
    ret,img=cap.read()
    gray=cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces=face_cascade.detectMultiScale(gray, 1.3, 5)
    for (x,y,w,h) in faces:
        circleX=x+w/2
        circleY=y+h/3
        #in the future, use more where your eyes are located than face
        #detect eyes instead of face and draw elipse around them
        box=(circleX-w/2,circleY-h/3,circleX+w/2,circleY+h/2)
        cv2.ellipse(img,(circleX,circleY),(w/2,h/5),0,0,360,(255,0,0),10)
        draw_rects(img,faces,(0,0,255))
        roi_gray=gray[y:y+h, x:x+w]
        roi_color=img[y:y+h, x:x+w]
    #cv2.circle(img,(200,200),50,(0,0,255),10)
    cv2.imshow('img',img)

    if cv2.waitKey(1) & 0xFF == ord('q'): break

cap.release()
cv2.destroyAllWindows()
